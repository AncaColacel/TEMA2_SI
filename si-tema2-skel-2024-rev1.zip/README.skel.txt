-------------------------------------------------------------------------------
Schelet Tema 2 SI 2024-2025 (v0.1):
-------------------------------------------------------------------------------

ATENȚIE: NU includeți acest Readme în arhiva sursă. Completați-l și includeți-l
PE CEL REAL, unde veți trece toate detaliile de construcție / arhitectură / 
implementare cerute în enunț!

Este recomandat să lucrați în interiorul acestui director al scheletului
(sfat: redenumiți-l, că nu va mai fi schelet după ce începeți rezolvarea :P).

Aveți următoarele helpers:

1. Makefile-ul inclus
======================

FIRST THINGS FIRST: editați Makefile-ul și introduceți fișierele care doriți să
facă parte din fiecare din arhive, mai ales cele sursă (valorile implicite sunt
recomandate, însă depinde de abordarea aleasă!)!

Rulați următoarele, de preferat, în ordine:

  * `make bin_archive`: generează arhiva binară;
  * `make checksum`: suprascrie fișierul CHECKSUM cu noul checksum;
  * `make source_archive`: generează arhiva cu fișierele sursă din directorul
    curent (exceptând, desigur, orice e binar);

OBLIGATORIU: INSPECTAȚI MANUAL CONȚINUTUL ACESTEIA pentru a vedea că v-a inclus
tot ce doriți să trimiteți!

2. Script testare folosind qemu:
==========================

Mai întâi, asigurați-vă că ați urmat convențiile de nume pe care le folosește
scriptul (cele din enunț, la denumirile din arhiva binară). Dacă nu, editați
scriptul și furnizați parametrii necesari!

Rulați scriptul:
> make run

(în caz de probleme de rulare, inspectați scriptul + outputul qemu!)

Dacă doriți să porniți și simulatorul de GPS, din alt terminal (de pe sistemul
gazdă!) și în paralel cu qemu pornit (scriptul de launch crează pipe-ul FIFO),
rulați scriptul:
> make gps_emu

Atenție: prima dată, Makefile-ul va instala într-un virtualenv toate
dependențele necesare, nu întrerupeți! Dacă o faceți, ștergeți directorul .venv
și reluați procesul!

Pentru a ieși sau da comenzi de hipervizor din consola `qemu`, folosiți
combinația "C-a, h" pentru a vedea un ecran de ajutor (Ctrl+a, luați mâna de pe
toate tastele, apoi apăsați tasta comenzii, e.g. 'h' pentru help, 'x' pentru
exit -- fără a ține Ctrl apăsat pt ultima tastă!).


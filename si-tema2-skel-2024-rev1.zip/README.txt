Readme Tema 2 SI 2024-2025
-------------------------------------------------------------------------------
Prenume NUME, Grupă <-- TODO: completați aici!
-------------------------------------------------------------------------------

TODO: De povestit, pe scurt (10-30 linii), ce și cum ați făcut.

Also, must read: README.skel.txt !

